const express = require('express');
const Sequelize = require('sequelize');
const dotenv = require('dotenv');

dotenv.config(); // Carrega as variáveis de ambiente do arquivo .env

const app = express();
const port = process.env.PORT || 3307;

// Conexão com o banco de dados MySQL usando Sequelize (corrigido)
const sequelize = new Sequelize('imc_tracker', 'novo', 'senha123', { // DB_NAME alterado para 'imc_tracker'
    host: 'localhost',
    dialect: 'mysql'
});

// Definição dos modelos Sequelize
const Peso = sequelize.define('Peso', {
    id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    user_id: {
        type: Sequelize.INTEGER,
        allowNull: false
    },
    peso: {
        type: Sequelize.FLOAT,
        allowNull: false
    },
    data: {
        type: Sequelize.DATE,
        allowNull: false
    }
});

const Objetivo = sequelize.define('Objetivo', {
    user_id: {
        type: Sequelize.INTEGER,
        primaryKey: true
    },
    peso: {
        type: Sequelize.FLOAT,
        allowNull: false
    }
});

// Middleware para analisar o corpo das requisições POST como JSON
app.use(express.json());

// Testa a conexão com o banco de dados (corrigido)
sequelize
    .authenticate()
    .then(() => {
        console.log('Conectado ao banco de dados MySQL com sucesso!');
        // Sincroniza os modelos com o banco de dados (cria as tabelas se não existirem)
        sequelize.sync();
    })
    .catch(err => {
        console.error('Erro ao conectar ao banco de dados MySQL:', err);
    });

// Endpoint para salvar o peso do usuário (corrigido)
app.post('/api/pesos', (req, res) => {
    const { userId, weight, date } = req.body;

    Peso.create({ user_id: userId, peso: weight, data: date })
        .then(pesoCriado => {
            res.status(201).json(pesoCriado);
        })
        .catch(err => {
            console.error('Erro ao salvar peso:', err);
            res.status(500).json({ error: 'Erro interno do servidor' });
        });
});

// Endpoint para salvar ou atualizar o objetivo de peso do usuário (corrigido)
app.post('/api/objetivo', (req, res) => {
    const { userId, goal } = req.body;

    Objetivo.upsert({ user_id: userId, peso: goal })
        .then(() => {
            res.json({ userId, goal });
        })
        .catch(err => {
            console.error('Erro ao salvar/atualizar objetivo:', err);
            res.status(500).json({ error: 'Erro interno do servidor' });
        });
});

// Endpoint para obter os pesos e o objetivo do usuário (corrigido)
app.get('/api/dados-usuario/:userId', (req, res) => {
    const userId = req.params.userId;

    Promise.all([
        Peso.findAll({ where: { user_id: userId }, order: [['data', 'DESC']] }),
        Objetivo.findOne({ where: { user_id: userId } })
    ])
        .then(([pesos, objetivo]) => {
            res.json({ pesos, objetivo });
        })
        .catch(err => {
            console.error('Erro ao buscar dados do usuário:', err);
            res.status(500).json({ error: 'Erro interno do servidor' });
        });
});


app.use(express.static('public')); 

// Rota para servir o arquivo index.html
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/public/index.html');
});
app.get('/landing', (req, res) => {
  res.sendFile(__dirname + '/public/landing.html');
});
app.get('/login', (req, res) => {
  res.sendFile(__dirname + '/public/login.html');
});

app.listen(port, () => {
    console.log(`Servidor rodando em http://localhost:${port}`);
});
