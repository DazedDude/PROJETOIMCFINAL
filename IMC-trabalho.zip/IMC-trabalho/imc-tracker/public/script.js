document.addEventListener('DOMContentLoaded', function () {
    const weightInput = document.getElementById('weight-input');
    const saveWeightBtn = document.getElementById('save-weight-btn');
    const goalInput = document.getElementById('goal-input');
    const saveGoalBtn = document.getElementById('save-goal-btn');
    const bmiValue = document.getElementById('bmi-value');
    const weightValue = document.getElementById('weight-value');
    const goalWeightValue = document.getElementById('goal-weight-value');

    let weights = [];
    let goalWeight = null;

    saveWeightBtn.addEventListener('click', function () {
        const weight = parseFloat(weightInput.value);
        if (!isNaN(weight) && weight > 0) {
            weights.push({ date: new Date(), weight });
            weightInput.value = '';
            console.log('Weights:', weights); // Log para depuração
            updateBMI();
            updateProgress();
        } else {
            alert('Por favor, insira um peso válido.');
        }
    });

    saveGoalBtn.addEventListener('click', function () {
        const goal = parseFloat(goalInput.value);
        if (!isNaN(goal) && goal > 0) {
            goalWeight = goal;
            goalWeightValue.textContent = goal + ' kg';
            goalInput.value = '';
            updateProgress();
        } else {
            alert('Por favor, insira um objetivo de peso válido.');
        }
    });

    function updateBMI() {
        if (weights.length > 0) {
            const latestWeight = weights[weights.length - 1].weight;
            const height = 1.75; // Assume uma altura fixa para simplificar
            const bmi = (latestWeight / (height * height)).toFixed(2);
            bmiValue.textContent = bmi;
            weightValue.textContent = latestWeight + ' kg';
        }
    }

    function updateProgress() {
        if (weights.length > 0 && goalWeight) {
            const initialWeight = weights[0].weight;
            const latestWeight = weights[weights.length - 1].weight;
            const progress = calculateProgress(initialWeight, latestWeight, goalWeight);
            updateProgressCircle(progress);
        }
    }

    function calculateProgress(initial, current, goal) {
        const totalChange = Math.abs(goal - initial);
        const currentChange = Math.abs(current - initial);
        const progress = (currentChange / totalChange) * 100;
        return Math.min(Math.max(progress, 0), 100);
    }

    function updateProgressCircle(progress) {
        const progressCircle = document.getElementById('progress-circle');
        const progressText = document.getElementById('progress-text');
        progressCircle.style.background = `conic-gradient(
            #4d5bf9 ${progress * 3.6}deg,
            #cadcff ${progress * 3.6}deg
        )`;
        progressText.textContent = `${Math.round(progress)}%`;
    }
});
